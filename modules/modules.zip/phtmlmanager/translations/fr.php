<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{chtmlmanager}prestashop>configure_5a0b018d97f49043e9cf1cebd31e3408'] = 'Choisissez la langue	';
$_MODULE['<{chtmlmanager}prestashop>configure_8b0e6c7cc07c08ee8846a3e78a76f087'] = 'Texte personnalisé	';
