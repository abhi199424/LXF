Compatible with layered navigation, fast and simple, this module allows to use the system of "infinite scroll" on all pages with products listing.
This module is developped by Kiwik (webagency certified Gold, with a team dedicated to support)


System of vertical scrolling without pagination
Simple use, navigation easy and intuitive
Compatibile with layered navigation of Prestashop
Compliant with Advanced Search 4 (Presta Module)
SEO friendly
Disponible for all pages with product listing:
  - Category pages
  - Search results pages
  - Bestsellers pages
  - New products pages
  - Suppliers pages
  - Manufacturers pages
  - Promotions pages 



- User experience augmented : addition of the functionality innovative (used by Facebook and Google)
- Better transformation tax : no more classical pagination system which makes access to products arduous.
- Top performance : no more slow-downs with innovative preloading cache. No pages recharging, displaying is instant and faster than standard pagination system.
- Compatibility with layered navigation of Prestashop
- Module developped by certified agency with a support managed by a dedicated team