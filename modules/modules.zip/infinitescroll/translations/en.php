<?php
/**
 * Infinite scroll premium
 *
 * @author    Studio Kiwik
 * @copyright Studio Kiwik 2014-2017
 * @license   http://licences.studio-kiwik.fr/infinitescroll
 */

global $_MODULE;
$_MODULE = array();
$_MODULE['<{infinitescroll}prestashop>infinitescroll_9d2861a099c1126bd0d865b1c95a5361'] = 'Infinite Scroll Premium';
$_MODULE['<{infinitescroll}prestashop>infinitescroll_48688076588027f85ad98fc9b1004b4f'] = 'Informations about the module';
$_MODULE['<{infinitescroll}prestashop>infinitescroll_c5711e5b5555e33f4a97aec1eb6f9944'] = 'Infinite Scroll Premium Module version';
$_MODULE['<{infinitescroll}prestashop>infinitescroll_096259656131f2e5953c1130d5bf25a2'] = 'Publisher';
$_MODULE['<{infinitescroll}prestashop>infinitescroll_7c7177f5bef0ef7b42214ddbef08a2a4'] = 'Studio Kiwik';
$_MODULE['<{infinitescroll}prestashop>infinitescroll_792e385abd9ffd008bc9d3151517b38f'] = 'web agency certified PrestaShop';
